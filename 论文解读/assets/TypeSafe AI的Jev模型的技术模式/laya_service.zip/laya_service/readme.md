### 二、启动
bash
pip install fastapi uvicorn
python server.py
# 或
uvicorn server:app --host 0.0.0.0 --port 8000 --workers 1

### 三、调用示例
重排
bash
curl -X POST http://localhost:8000/rerank \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Laya 的中文支持怎么样？",
    "top_k": 3,
    "documents": [
      {"id": "1", "text": "Laya-multilingual 支持 100+ 语言，中文属于 mmBERT 覆盖范围。"},
      {"id": "2", "text": "今天股市大涨。"},
      {"id": "3", "text": "中文场景建议使用 multilingual checkpoint，并先做温度校准。"},
      {"id": "4", "text": "vLLM 的 PagedAttention 用于优化 KV cache。"}
    ]
  }'
响应：

json
{
  "results": [
    {"id": "1", "text": "Laya-multilingual 支持 ...", "orig_index": 0, "laya_score": 2.87},
    {"id": "3", "text": "中文场景建议使用 ...",       "orig_index": 2, "laya_score": 2.65},
    {"id": "4", "text": "vLLM 的 PagedAttention ...", "orig_index": 3, "laya_score": 0.71}
  ],
  "latency_ms": 48.3
}
分类
bash
curl -X POST http://localhost:8000/classify \
  -H "Content-Type: application/json" \
  -d '{
    "state": {"body": "我被重复扣费了，请退款。"},
    "questions": {
      "intent": {
        "type": "choice",
        "instructions": "用户诉求属于哪一类？",
        "criteria": {
          "退款": "退款、退费、多扣钱",
          "技术": "报错、无法使用",
          "其他": "其他"
        }
      }
    }
  }'