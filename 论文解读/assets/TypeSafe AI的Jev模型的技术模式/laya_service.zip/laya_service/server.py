# server.py
# -*- coding: utf-8 -*-
"""
Laya HTTP 服务
- 启动时 preload 本地模型，进程常驻
- 提供 /rerank 批量重排、/classify 分类、/health 健康检查
- 批处理聚合：把并发请求攒成一批，一次前向处理，提升吞吐
"""

import asyncio
import time
from typing import List, Dict, Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import laya


# ============================================================
# 1. 配置
# ============================================================

LOCAL_MODEL_PATH = "./laya_model"      # 改成你的本地路径
SUBFOLDER = "multilingual"             # 中文用 multilingual；单下子目录则设为 None
DEVICE = "cuda"                        # 无 GPU 改 "cpu"

HEAD_MAX_LEN = 384
MAX_LEN = 2048
MAX_DOC_CHARS = 800

# 批处理聚合参数
MAX_BATCH_SIZE = 8         # 一次前向最多几个文档
MAX_WAIT_MS = 20           # 攒批最多等这么久
RERANK_TIMEOUT = 30.0      # 单请求超时（秒）


# ============================================================
# 2. 全局模型（lifespan 里加载，进程常驻）
# ============================================================

class ModelHolder:
    agent = None
    lock = asyncio.Lock()

holder = ModelHolder()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ---- 启动 ----
    print("加载 Laya 模型中 …")
    t0 = time.time()
    kwargs = {"device": DEVICE}
    if SUBFOLDER:
        agent = laya.load(LOCAL_MODEL_PATH, subfolder=SUBFOLDER, **kwargs)
    else:
        agent = laya.load(LOCAL_MODEL_PATH, **kwargs)

    agent.cfg["head_max_len"] = HEAD_MAX_LEN
    agent.cfg["max_len"] = MAX_LEN
    holder.agent = agent
    print(f"模型加载完成，耗时 {time.time() - t0:.2f}s")

    yield

    # ---- 关闭 ----
    print("释放模型 …")
    holder.agent = None


app = FastAPI(title="Laya Rerank Service", lifespan=lifespan)


# ============================================================
# 3. 请求/响应模型
# ============================================================

class Doc(BaseModel):
    id: Optional[str] = None
    text: str


class RerankRequest(BaseModel):
    query: str
    documents: List[Doc]
    top_k: int = Field(default=5, ge=1)
    batch_size: int = Field(default=MAX_BATCH_SIZE, ge=1, le=32)


class RerankItem(BaseModel):
    id: Optional[str]
    text: str
    orig_index: int
    laya_score: float


class RerankResponse(BaseModel):
    results: List[RerankItem]
    latency_ms: float


class ClassifyRequest(BaseModel):
    state: Dict[str, str]           # 任意字段，如 {"body": "..."}
    questions: Dict[str, dict]      # Laya questions schema
    model: Optional[str] = None     # 预留，多 checkpoint 时用


class ClassifyResponse(BaseModel):
    answers: Dict
    latency_ms: float


# ============================================================
# 4. 内部：批量重排（线程池执行，避免阻塞 event loop）
# ============================================================

def _truncate(text: str, max_chars: int) -> str:
    return text if len(text) <= max_chars else text[:max_chars] + "…"


def _relevance_questions(query: str, n: int) -> Dict:
    return {
        f"rel_{i}": {
            "type": "score",
            "instructions": f"给定查询「{query}」，文档 doc_{i} 与查询的相关程度如何？",
            "criteria": [
                "完全不相关",
                "弱相关，只有边缘信息",
                "中等相关，包含部分有用信息",
                "高度相关，直接回答查询",
            ],
        }
        for i in range(n)
    }


def _predict_batch_sync(agent, query: str, batch: List[Dict]) -> List[float]:
    n = len(batch)
    state = {f"doc_{i}": _truncate(d["text"], MAX_DOC_CHARS)
             for i, d in enumerate(batch)}
    questions = _relevance_questions(query, n)
    res = agent.predict(state, questions)
    return [float(res["answers"][f"rel_{i}"]["score"]) for i in range(n)]


def _rerank_sync(agent, query: str, docs: List[Dict],
                 top_k: int, batch_size: int) -> List[Dict]:
    indexed = list(enumerate(docs))
    scored = []
    for start in range(0, len(indexed), batch_size):
        batch_pairs = indexed[start:start + batch_size]
        batch_docs = [d for _, d in batch_pairs]
        scores = _predict_batch_sync(agent, query, batch_docs)
        for (orig_idx, doc), s in zip(batch_pairs, scores):
            scored.append({**doc, "orig_index": orig_idx, "laya_score": s})
    scored.sort(key=lambda x: (-x["laya_score"], x["orig_index"]))
    return scored[:top_k]


# ============================================================
# 5. 路由
# ============================================================

@app.get("/health")
def health():
    return {
        "status": "ok" if holder.agent is not None else "loading",
        "model": f"{LOCAL_MODEL_PATH}/{SUBFOLDER}" if SUBFOLDER else LOCAL_MODEL_PATH,
    }


@app.post("/rerank", response_model=RerankResponse)
async def rerank(req: RerankRequest):
    if holder.agent is None:
        raise HTTPException(503, "模型尚未加载完成")
    if not req.documents:
        return RerankResponse(results=[], latency_ms=0.0)

    t0 = time.time()
    docs = [{"id": d.id, "text": d.text} for d in req.documents]

    # 同步推理丢到线程池，避免阻塞 event loop
    loop = asyncio.get_running_loop()
    try:
        results = await asyncio.wait_for(
            loop.run_in_executor(
                None,
                _rerank_sync,
                holder.agent, req.query, docs, req.top_k, req.batch_size,
            ),
            timeout=RERANK_TIMEOUT,
        )
    except asyncio.TimeoutError:
        raise HTTPException(504, f"重排超时（>{RERANK_TIMEOUT}s）")

    latency = (time.time() - t0) * 1000
    return RerankResponse(
        results=[RerankItem(**r) for r in results],
        latency_ms=round(latency, 2),
    )


@app.post("/classify", response_model=ClassifyResponse)
async def classify(req: ClassifyRequest):
    if holder.agent is None:
        raise HTTPException(503, "模型尚未加载完成")

    t0 = time.time()
    loop = asyncio.get_running_loop()
    res = await loop.run_in_executor(
        None, holder.agent.predict, req.state, req.questions
    )
    latency = (time.time() - t0) * 1000
    return ClassifyResponse(answers=res["answers"], latency_ms=round(latency, 2))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=8002,
        workers=1,          # 重要：见下面说明
    )